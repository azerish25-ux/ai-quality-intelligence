<!-- failurelens-report:v1 -->
## FailureLens evidence-grounded triage

- Tested head: `6afa859537114ed97f3f5ee95e2f3a6bfed92981`
- Base: `unknown`
- Run: `c-f79e3f6bdd5f1fa6fef9/0.zip` attempt `1`
- Scope completeness: **COMPLETE** (2/2 inputs)
- Evidence publication validation: passed=1

### Classifications
- `infrastructure_failure`: 1

### Advisory status
NO_BLOCKER_IDENTIFIED_IN_OBSERVED_SCOPE

This report is advisory. It does not approve a release, suppress failures, or replace human review.
