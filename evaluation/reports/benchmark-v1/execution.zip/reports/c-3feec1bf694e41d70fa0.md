<!-- failurelens-report:v1 -->
## FailureLens evidence-grounded triage

- Tested head: `6afa859537114ed97f3f5ee95e2f3a6bfed92981`
- Base: `unknown`
- Run: `c-3feec1bf694e41d70fa0/0.zip` attempt `1`
- Scope completeness: **COMPLETE** (2/2 inputs)
- Evidence publication validation: passed=1

### Classifications
- `product_defect`: 1

### Advisory status
HOLD_FOR_REVIEW

This report is advisory. It does not approve a release, suppress failures, or replace human review.
