<!-- failurelens-report:v1 -->
## FailureLens evidence-grounded triage

- Tested head: `6afa859537114ed97f3f5ee95e2f3a6bfed92981`
- Base: `unknown`
- Run: `c-a1a1e6f9e6ed3caad58b/0.zip` attempt `1`
- Scope completeness: **COMPLETE** (2/2 inputs)
- Evidence publication validation: passed=1

### Classifications
- `product_defect`: 1

### Advisory status
HOLD_FOR_REVIEW

This report is advisory. It does not approve a release, suppress failures, or replace human review.
