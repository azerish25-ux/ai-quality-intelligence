<!-- failurelens-report:v1 -->
## FailureLens evidence-grounded triage

- Tested head: `6afa859537114ed97f3f5ee95e2f3a6bfed92981`
- Base: `unknown`
- Run: `c-ae3eacbb88a8cca4f217/0.zip` attempt `1`
- Scope completeness: **COMPLETE** (2/2 inputs)
- Evidence publication validation: passed=1

### Classifications
- `insufficient_evidence`: 1

### Advisory status
HOLD_FOR_REVIEW

This report is advisory. It does not approve a release, suppress failures, or replace human review.
