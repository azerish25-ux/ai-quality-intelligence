<!-- failurelens-report:v1 -->
## FailureLens evidence-grounded triage

- Tested head: `158d288252d348ca55e3d2a33e109de882196567`
- Base: `unknown`
- Run: `c-9c125e4dbd695caf77dd-current` attempt `1`
- Scope completeness: **COMPLETE** (2/2 inputs)
- Evidence publication validation: passed=1

### Classifications
- `insufficient_evidence`: 1

### Advisory status
HOLD_FOR_REVIEW

This report is advisory. It does not approve a release, suppress failures, or replace human review.
