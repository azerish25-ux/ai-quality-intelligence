<!-- failurelens-report:v1 -->
## FailureLens evidence-grounded triage

- Tested head: `13bdd62c924a3230825b6d9304f449f887c8e7fe`
- Base: `unknown`
- Run: `c-1bccfdae73da398eb2a0-1` attempt `1`
- Scope completeness: **COMPLETE** (1/1 inputs)
- Evidence publication validation: passed=1

### Classifications
- `product_defect`: 1

### Advisory status
HOLD_FOR_REVIEW

This report is advisory. It does not approve a release, suppress failures, or replace human review.
